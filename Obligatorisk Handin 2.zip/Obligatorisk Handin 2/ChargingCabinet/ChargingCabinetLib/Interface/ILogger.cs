﻿namespace ChargingCabinetLib.Interface
{
    public interface ILogger
    {
        void Log(string writeToLog);
    }
}